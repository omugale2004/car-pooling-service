import imp
from db.models.tets import *
from db.models.test1 import *
from db.models.member import *
from db.models.car import *
from db.models.chitchat_preference import *
from db.models.city import *
from db.models.member_preference import *
from db.models.music_preference import *
from db.models.member_car import *